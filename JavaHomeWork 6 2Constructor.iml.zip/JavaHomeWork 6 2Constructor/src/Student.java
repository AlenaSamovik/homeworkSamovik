public class Student {
    //1 Создайте класс Student, содержащий поля name и group.
    // Поля сделайте приватными.

    private String name;
    private int group;
//3 Создайте конструктор, который принимает значения для инициализации поля name.
    public Student(String name) {
        this.name = name;
    }

    public Student(String name, int group) {
        this(name);
        this.group = group;
    }
    public Student(Student student){
        this.name = student.name;
        this.group = student.group;

    }
//2 Создайте геттеры и сеттеры для этих полей.
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }

}


