import java.util.Scanner;


public class Main {

    public static void main(String[] args) {

        Student student1 = new Student("Alena");//6 В основной программе создайте переменную student1,проинициализируйте её с помощью оператора new и с помощью конструктора.
        Student student2 = student1; //  7 В переменную student2 присвойте значение student1.
        Student student3 = new Student(student1); //  8 В переменную student3 присвойте значение,полученное с помощью клонирующего конструктора.
        student1.setName("Anna");//9 Измените значение поля name у student1.
        System.out.println(student1.getName()); //   10 Выведите на консоль значения полей student1, student2 и student3.
        System.out.println(student2.getName());
        System.out.println(student3.getName());




    }
}





