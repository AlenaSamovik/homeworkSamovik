public class Main {
    public static void main(String[] args) {
        System.out.println(" _" +  "_");
        System.out.println("| " + " |");
        System.out.println("| " + " |");
        System.out.println(" _" +  "_");
    }
}