public class Main {
    public static void main(String[] args) {
        System.out.printf(
                "%.2f , %.2f , %.2f ", 3.222, 4.333, 5.444);
    }
}