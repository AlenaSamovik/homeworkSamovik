import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности:
        // 1 n - номер дома, в котором Вы живёте
        // (без учёта дробей, корпусов, строений и т.д). Создайте массив целых чисел.
        // Заполните массив числами от 0 до n*10, выведите массив в консоль.
        int[] streetArray = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        // String asString = Arrays.toString(streetArray);
        // System.out.println(asString);


        // for (int i = 0; i < streetArray.length; i++ ){
        // System.out.println(streetArray[i]);

        for (int j : streetArray) {
            System.out.println(j);
        }
    }
}
