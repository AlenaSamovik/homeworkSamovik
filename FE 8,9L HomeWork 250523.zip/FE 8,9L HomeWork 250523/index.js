"use strict";

// Вывод таблицы умножения для определенного числа в массив, 
// каждый элемент массива в виде: число * итератор = результат. 
// Для формирования строки используйте интерполяцию.

// function getMultiplication(number) {
// let array = [];
// let i = 1;

// while (i <= 10) {
//     let result = number * i;
//     let row = `${number} * ${i} = ${result}`;
//         array.push(row);
//         i++;
//     }
//     return array;
// }

// let multiplicationTable = getMultiplication(7);
// console.log(multiplicationTable);


// Поиск первого положительного числа в массиве: 
// есть массив чисел и нужно найти первое число, 
// которое является положительным.

// function findFirstPositiveNumber(numbers) {
// let index = 0;
// let firstPositiveNumber = null;

// while (index < numbers.length && firstPositiveNumber === null) {
//     let currentNumber = numbers[index];
//         if (currentNumber > 0) {
//         firstPositiveNumber = currentNumber;
//     }

// index++;
// }

// return firstPositiveNumber;
// }

// let numbersArray = [-5, -2, 0, 7, -1, 9];
// let firstPositive = findFirstPositiveNumber(numbersArray);
// console.log("The first positive number is:", firstPositive);


// Генерация случайного пароля: есть некая константа, 
// которая отвечает за длину пароля. 
//Сгенерируйте рандомный пароль до указанной длины, 
//используя Math.random:

// function generateRandomPassword(length) {
// let charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,.;:/*#";
// let password = "";
// let i = 0;

// while (i < length) {
//     let randomIndex = Math.floor(Math.random() * charset.length);
//     let randomChar = charset.charAt(randomIndex);
// password += randomChar;
// i++;
// }
//     return password;
// }

// let passwordLength = 7;
// let randomPassword = generateRandomPassword(passwordLength);
// console.log("Generated password is:", randomPassword);

// Объединение элементов массива в строку при помощи конкатенации: 
// есть массив строк (например, список покупок) - 
// необходимо вывести его в виде строки.

// function joinArrayToString(array) {
//     let result = "";

// for (let i = 0; i < array.length; i++) {
//     result += array[i];
//         if (i !== array.length - 1) {
//             result += ", ";
//         }
//     }
//     return result;
// }

// let shoppingList = ["butter", "bread", "salami", "water"];
// let shoppingListString = joinArrayToString(shoppingList);
// console.log("Things to buy:", shoppingListString);



///Поиск наибольшего числа в массиве

// function findBiggestNumber(array) {
// if (array.length === 0) {
//     return undefined;
// }

// let max = array[0];

// for (let i = 1; i < array.length; i++) {
//     if (array[i] > max) {
//         max = array[i];
//     }
// }
//     return max;
// }


// let numbers = [2,987,-34,54,234567,65,345,-11,];
// let maxNumber = findBiggestNumber(numbers);
// console.log("The biggest number is:", maxNumber);



// Переворот строки: есть некая константа, содержащая строку. 
// Необходимо вывести строку наоборот, используя цикл for

// let string = "Имя твое - птица в руке.";
// let reversedString = "";

// for (let i = string.length - 1; i >= 0; i--) {
//     reversedString += string[i];
// }

// console.log("The reversed line is:", reversedString);



// Подсчет количества гласных букв в строке: есть строка и массив гласных в алфавите 
// (можно выбрать английский). Необходимо посчитать, сколько раз встречаются 
// гласные в этой строке. 
// Методы для решения этой задачи Вы найдете в файлике к уроку.

// let string = "Имя твое - льдинка на языке.";
// let vowels = ['а', 'о', 'у', 'ы', 'э', 'я', 'ё', 'ю', 'и', 'е'];
// let vowelsCount = 0;

// for (let i = 0; i < string.length; i++) {
//     let char = string[i].toLowerCase();
//     if (vowels.includes(char)) {
//     vowelsCount++;
//     }
// }

// console.log("The number of vowels is:", vowelsCount);



// Напишите функцию, которая принимает массив чисел и возвращает их сумму.

// function sumArray(numbers) {
// let sum = 0;
// for (let i = 0; i < numbers.length; i++) {
//     sum += numbers[i];
// }
// return sum;
// }

// let result = sumArray(numbers);
// console.log("The sum of numbers is:", result);



// Напишите функцию findMax, которая принимает массив чисел 
// и возвращает максимальное число из этого массива.

// function findMax(numbers) {
// let max = numbers[0];
// for (let i = 1; i < numbers.length; i++) {
//     if (numbers[i] > max) {
//     max = numbers[i];
//     }
// }
// return max;
// }

// const numbers = [1, 5, 2, 8, 3];
// const result = findMax(numbers);
// console.log("The biggest number is:", result);



// Напишите функцию reverseArray, которая принимает массив и возвращает новый массив, 
// в котором элементы идут в обратном порядке.

// function reverseArray(array) {
// const reversedArray = [];
// for (let i = array.length - 1; i >= 0; i--) {
//     reversedArray.push(array[i]);
// }
// return reversedArray;
// }

// const array = [123,76543,-345,64,34,-31234];
// const reversed = reverseArray(array);
// console.log("Source array:", array);
// console.log("Reversed array:", reversed);



// Напишите функцию, которая принимает массив строк и возвращает новый массив, 
// содержащий только строки, начинающиеся с заданной буквы.

// function sortStringsByLetter(strings, letter) {
// let sortedStrings = [];
// for (let i = 0; i < strings.length; i++) {
//     let currentString = strings[i];
//     if (currentString.charAt(0) === letter) {
//         sortedStrings.push(currentString);
//     }
// }
// return sortedStrings;
// }

// let strings = ["Напишите", "функцию", "которая", "принимает", "массив", "содержащий", "буквы"];
// let letter = "к";
// let filtered = sortStringsByLetter(strings, letter);
// console.log("Source array:", strings);
// console.log(`Lines beginning with "${letter}":`, filtered);



//Напишите функцию, которая принимает число и возвращает его факториал.

// function factorial(number) {
// if (number === 0 || number === 1) {
//     return 1;
// }

// let result = 1;
// for (let i = 2; i <= number; i++) {
//     result *= i;
// }

// return result;
// }

// let num = 7;
// let result = factorial(num);
// console.log(`Факториал числа ${num}:`, result);



// Напишите функцию, которая принимает число и возвращает "Fizz", если число делится на 3, 
// "Buzz", если число делится на 5, 
// и "FizzBuzz", если число делится и на 3, и на 5. 
// В остальных случаях вернуть само число.

// function fizzBuzz(number) {
// if (number % 3 === 0 && number % 5 === 0) {
//     return "FizzBuzz";
// } else if (number % 3 === 0) {
//     return "Fizz";
// } else if (number % 5 === 0) {
//     return "Buzz";
// } else {
//     return number;
// }
// }

// console.log(fizzBuzz(33)); 
// console.log(fizzBuzz(55));
// console.log(fizzBuzz(120)); 
// console.log(fizzBuzz(71));  



// Создайте функциональное выражение calculateCircleArea, 
// которое принимает объект circle с свойством radius и возвращает площадь круга.   


// Создайте функциональное выражение calculateAverageGrade, 
// которое принимает объект student с массивом оценок grades 
// и возвращает среднюю оценку студента (попробуйте использовать reduce, 
// описанный в файле предыдущего урока).

// function calculateAverageGrade(student) {
// let sum = student.grades.reduce(function(total, grade) {
//     return total + grade;
// }, 0);
// let average = sum / student.grades.length;
// return average;
// }

// let student = {grades: [56,87,98,54,67]};
// let averageGrade = calculateAverageGrade(student);
// console.log("Student's avarage grade is: " + averageGrade);




// Создайте функциональное выражение getFullName, 
// которое принимает объект person с свойствами firstName 
// и lastName и возвращает полное имя.

// function getFullName(person) {
// return person.firstName + " " + person.lastName;
// }

// let person = {
// firstName: "Alena",
// lastName: "Samovik"
// };
// var fullName = getFullName(person);
// console.log("Full name: " + fullName);


// Создайте объект calculator с двумя свойствами operand1 и operand2, 
// и двумя методами: add и multiply. Метод add должен принимать два числа 
// и возвращать их сумму, а метод multiply должен принимать два числа 
// и возвращать их произведение.

// let calculator = {
// operand1: 0,
// operand2: 0,
// add: function (num1, num2) {
//     return num1 + num2;
// },
// multiply: function (num1, num2) {
//     return num1 * num2;
// }
// };

// let sum = calculator.add(2,3);
// console.log("The sum of numbers: " + sum);

// let product = calculator.multiply(7,8);
// console.log("The product of numbers: " + product);