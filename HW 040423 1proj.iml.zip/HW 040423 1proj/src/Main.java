import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Проект 1. Используйте while:
        // Ты попросил друзей скинуться на подарок на твой День Рождения.
        // Каждый друг случайным образом может подарить тебе одну купюру
        // номиналом 500, 1000, 2000 или 5000 рублей.
        // Твоя цель - новенький игровой ПК, который стоит 100 000 рублей.
        // Как только друзья подарят тебе нужную сумму (или даже чуть больше),
        // останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!


        //do-while. IN this case i like it more
        int sum1 = 0;
        int prise = 100000;
        Random rnd = new Random();
        do {
            System.out.println(" We have to collect a little bit more!!!" + sum1);
            int gift1 = rnd.nextInt(4);
            int b = 0;
            switch (gift1) {
                case 0 -> b = 500;
                case 1 -> b = 1000;
                case 2 -> b = 2000;
                case 3 -> b = 5000;
            }
            sum1 += b;
        } while (sum1 < prise);
        System.out.println("We have done it " + prise + " let's go to the bar");



        //while. As You like.
        int sum2 = 0;
        int amountWeNeed = 100000;
        Random random = new Random();
        while (sum2 < amountWeNeed) {
            System.out.println(" We have to collect a little bit more!!!" + sum2);
            int gift = random.nextInt(4);
            int a = 0;
            switch (gift) {
                case 0 -> a = 500;
                case 1 -> a = 1000;
                case 2 -> a = 2000;
                case 3 -> a = 5000;
            }
            sum2 += a;
        }
        System.out.println("We have done it " + amountWeNeed + " let's go to the bar");
    }
}