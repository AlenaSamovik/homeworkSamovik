import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Проект 3.
        // Дан Enum месяцев. Пользователь вводит имя текущего месяца в консоль.
        // Программа должна вывести все месяцы, кроме того, что ввёл пользователь.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите месяц.");
        String monthUser = scanner.nextLine().toUpperCase();
        Month X = Month.valueOf(monthUser);

        for (Month month : Month.values()) {
            if (month != X) {
                System.out.println((month.ordinal() + 1) + " " + month.name());
            }
        }


    }
}