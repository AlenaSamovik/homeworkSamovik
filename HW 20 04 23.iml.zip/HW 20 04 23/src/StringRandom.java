
//Напишите аналог Random для генерации строк - StringRandom.
// В классе реализуйте набор публичных статических методов:
// первый метод генерирует слово заданной длины, состоящее из  английских букв (любой набор букв).
// Второй метод генерирует предложение из заданного количества разных слов.
// Третий метод генерирует текст из заданного количества разных предложений,
// разделяя предложения случайными знаками препинания из набора (. или ! или ? или …).
// В методе main сгенерируйте текст из 1000 предложений.


import java.util.Random;

public class StringRandom {
    //Для реализации StringRandom мы можем использовать методы генерации случайных чисел
    // из библиотеки Java и таблицу символов английского алфавита.
    // Вот как это может выглядеть:
    //В этом классе мы определяем три публичных статических метода,
    // каждый из которых генерирует строку заданного типа и длины.
    // Мы используем таблицу символов для английского алфавита, чтобы создавать слова и предложения,
    // и таблицу знаков препинания для создания случайных знаков препинания в предложениях.
    // Мы также используем класс Random для генерации случайных чисел для выбора случайных слов и знаков препинания.
    //Метод main генерирует текст из 1000 предложений и выводит его на консоль.
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private static final String PUNCTUATION = ".!?…";
    private static final Random RANDOM = new Random();

    public static String generateWord(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return sb.toString();
    }

    public static String generateSentence(int wordCount) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < wordCount; i++) {
            sb.append(generateWord(RANDOM.nextInt(10) + 1));
            sb.append(' ');
        }
        sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
        int punctuationIndex = RANDOM.nextInt(PUNCTUATION.length());
        sb.append(PUNCTUATION.charAt(punctuationIndex));
        return sb.toString();
    }

    public static String generateText(int sentenceCount) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentenceCount; i++) {
            sb.append(generateSentence(RANDOM.nextInt(10) + 1));
            sb.append(' ');
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        String text = generateText(1000);
        System.out.println(text);
    }
}



