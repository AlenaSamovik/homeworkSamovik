public class Main {
    public static void main(String[] args) {
        System.out.println("Police Department Brookberg city");
        System.out.println("Missing people");
        System.out.println();
        System.out.println("Name: " + "Mr. John Black");
        System.out.println("Age: " + "50");
        System.out.println("Height: " + "1.82");
        System.out.println();
        System.out.println("Name: " + "Mrs. Holy Black");
        System.out.println("Age: " + "43");
        System.out.println("Height: " + "1.72");
        System.out.println();
        System.out.println("Name: " + "Ms. Dolly Black");
        System.out.println("Age: " + "17");
        System.out.println("Height: " + "1.74");
        System.out.println();
        System.out.printf(
                "%.2f , %.2f , %.2f ", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.println(" _" +  "_");
        System.out.println("| " + " |");
        System.out.println("| " + " |");
        System.out.println(" _" +  "_");

    }
}