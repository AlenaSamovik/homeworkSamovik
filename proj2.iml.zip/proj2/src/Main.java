import java.util.Arrays;

public class Main {
    // Практика алгоритмов

    //Задание из собеседования Яндекс: дана строка вида AAABBBCCCDDEG…,
    // состоящая только из заглавных символов латинского алфавита.
    // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е.
    // количество букв записывается цифрой. Если буква одна, то цифра не
    // ставится.
  /*  public static char[] bubbleSort(char[] sortArr) {
        for (int i = 0; i < sortArr.length - 1; i++) {
            for (int j = 0; j < sortArr.length - i - 1; j++) {
                if (sortArr[j + 1] < sortArr[j]) {
                    int swap = sortArr[j];
                    sortArr[j] = sortArr[j + 1];
                    sortArr[j + 1] = (char) swap;
                }
            }
        }
        return sortArr;
    }
*/
    public static void main(String[] args) {
        String string = "ABBBCCCCCCDDDDDDDEEEEEEEEEE";
        StringBuilder result = new StringBuilder();

        char currentChar = string.charAt(0);
        int count = 1;

        for (int i = 1; i < string.length(); i++) {
            char ch = string.charAt(i);
            if (ch == currentChar) {
                count++;
            } else {
                result.append(currentChar);
                if (count > 1) {
                    result.append(count);
                }
                currentChar = ch;
                count = 1;
            }
        }

        // добавляю последний символ и его колич
        result.append(currentChar);
        if (count > 1) {
            result.append(count);
        }

        System.out.println(result.toString());
    }
}
        /*char[] sortArr = string.toCharArray();
        bubbleSort(sortArr);
        System.out.println(Arrays.toString(sortArr));
        int count = 1;
        for (int i = 1; i < sortArr.length; i++) {
            if (sortArr[i] == sortArr[i - 1]) {
                count++;
            } else {
                System.out.println(sortArr[i - 1] + ": " + count);
            }
        }
        System.out.println(sortArr[sortArr.length - 1] + ": " + count);
        ерунду посчитала
         */


