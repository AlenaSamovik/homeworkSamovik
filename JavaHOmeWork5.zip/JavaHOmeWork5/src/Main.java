import java.util.Scanner;

//Напишите метод, который принимает три строки и
// строку-разделитель. Метод возвращает единую строку,
// состоящую из исходных строк,
// разделённых строкой-разделителем. Например, на входе
// "один", "два", "три", "|". На выходе: "один|два|три"
public class Main {
    public static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Write a phrase.");
        String s1 = scanner.nextLine();
        System.out.println("Write a phrase.");
        String s2 = scanner.nextLine();
        System.out.println("Write a phrase.");
        String s3 = scanner.nextLine();
        String delimiter = "|";
        String s = concat(String s1 + String s2 + String s3 + String delimiter);
        System.out.println(s);
    }

    private static String concat(String s1, String s2, String s3, String delimiter) {
        return s1 + delimiter + s2 + delimiter + s3;
    }


}
