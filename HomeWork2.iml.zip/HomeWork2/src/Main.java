import javax.net.ssl.SSLContext;

public class Main {

    static final char INHABITED = 'Y';
    static final char UNINHABITED = 'N';
    static final char UNDIFINED = 'U';

    public static void main(String[] args) {

        System.out.println("1 Projekt");
        System.out.println("Zvezdnaja sistema Glize.");

        byte glizenumber = 123;
        short glizebrightness = 1253;
        int glizetemperature = 162333;
        long glizediameter = 1115742l;
        float glizeweight = 126299.55f;
        double glizedistance = 146534.5;
        boolean isSatellitepresent = true;
        char glizeinhabitation = INHABITED;


        System.out.println("Kodovii nomer sistemi - " + glizenumber + " Glize");
        System.out.println("Jarkost' - " + glizebrightness + " edinits ");
        System.out.println("Diametr - " + glizediameter + " km");
        System.out.println("Ves - " + glizeweight + " mass solntza");
        System.out.println("Rasstoianie do Zemli - " + glizedistance + " svetovih let");
        System.out.println("Nalichie planet sputnikov - " + isSatellitepresent);
        System.out.println("Est li zgizn - " + glizeinhabitation);

        glizetemperature = glizetemperature * 2;
        glizediameter = glizediameter / 20;
        glizeinhabitation = UNINHABITED;

        System.out.println("Posle jarkoi vspishki na Glize" + glizenumber + " pokazateli izmenilis:\ntemperatura "
                + glizetemperature);
        System.out.println("Diametr " + glizediameter);
        System.out.println("Est li zgizn " + glizeinhabitation);

        System.out.println("2 Projekt");
        int Price1 = 7;
        int Price2 = 2;
        int totalPrice;

        totalPrice = Price1 + Price2;
        System.out.println(totalPrice);
        totalPrice = Price1 - Price2;
        System.out.println(totalPrice);
        totalPrice = Price1 * Price2;
        System.out.println(totalPrice);
        totalPrice = Price1 / Price2;
        System.out.println(totalPrice);
        totalPrice = Price1 % Price2;
        System.out.println(totalPrice);

        System.out.println(" 3 PROEKT");
        System.out.println(5 % 4);
        System.out.println(15 % 3);

        int y1 = 2;
        if (y1 % 2 == 0) {
            System.out.println("y1 - chetnoe chislo");
        }
        int y2 = 17;
        if (y2 % 2 == 0) {
            System.out.println("y2 - chetnoe chislo");
        }
        int y3 = 13;
        if (y3 % 2 == 0) {
            System.out.println("y3 - chetnoe chislo");
        }
        int y4 = 14;
        if (y4 % 2 == 0) {
            System.out.println("y4 - chetnoe chislo");
        }

        int danochislo = 27555 % 10;
        System.out.println("posledniaa zifra " + danochislo);

        System.out.println(" 4 PROEKT");
        int i1 = 1;
        int i2 = 2;
        long l1 = 3;
        long l2 = 4;
        double d1 = 5;
        double d2 = 6;
        float f1 = 7;
        float f2 = 8;

        int result1 = i1 + i2;
        long result2 = l1 + l2;
        long result3 = i1 + l1;
        float result4 = i1 + f1;
        double result5 = i1 + d1;
        double result6 = l1 + d1;
        System.out.println(result1);
        System.out.println(result2);
        System.out.println(result3);
        System.out.println(result4);
        System.out.println(result5);
        System.out.println(result6);

        System.out.println("5 PROEKT");
        byte h1 = (byte) (127 + 1);
        System.out.println(h1);

    }
}
