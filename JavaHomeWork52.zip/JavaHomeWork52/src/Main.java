import javax.management.BadStringOperationException;
import java.util.Scanner;

public class Main {
    // Напишите метод, который выводит в консоль первый символ переданной в него строки.
    public static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Write a phrase.");
        String phrase = scanner.nextLine();
        text(phrase);

    }

    public static void text(String phrase) {
        System.out.println(phrase.charAt(0));
    }
}


