import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1 уровень сложности: Все задания можно выполнить в одном проекте.
// 1 Пользователь вводит число. Если число больше 0, то выполнить следующие
// операции:умножить число на 2, если оно нечётное;

// прибавить к числу 5, если если оно заканчивается на 5 или 0.
// Если число < 0, то взять его по модулю и разделить на 3.
// Результат вычисления вывести в консоль.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Vvedite chislo");
        int number = scanner.nextInt();
        if (number > 0 && number % 2 != 0) {
            System.out.println(number * 2);
        }
        if ((number % 10 == 5 || number % 10 == 0) && number > 0) {
            System.out.println(number + 5);
        }
        if (number < 0) {
            System.out.println((Math.abs(number)) / 3);
        }
        System.out.println();
        //  2 Пользователь вводит строку. Если строка начинается с цифры
//  (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9),то вывести эту цифру в консоль.
//  Если строка начинается со знака _ или знака -, то вывести в
// консоль строку без этого знака.
// Используйте методы startsWith, charAt и substring.
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Vvedite stroku");
        String stroka = scanner1.nextLine();
        if (stroka.startsWith("0") || stroka.startsWith("1") ||
        stroka.startsWith("2") || stroka.startsWith("3") ||
        stroka.startsWith("4") || stroka.startsWith("5") ||
        stroka.startsWith("6") || stroka.startsWith("7") ||
        stroka.startsWith("8") || stroka.startsWith("9")) {
            System.out.println(stroka.charAt(0));
        }
        if ((stroka.charAt(0) == '_') || (stroka.charAt(0) == '-')){
            System.out.println(stroka.substring(1));
        }
        System.out.println();
// 3 Пользователь вводит два числа.
// Если они не равны, то вывести в консоль их сумму,
// иначе вывести их произведение. Используйте тернарный оператор.
        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Vvedite chislo");
        int num = scanner2.nextInt();
        System.out.println("Vvedite drugoe chislo");
        int num1 = scanner2.nextInt();
        System.out.println(num != num1 ? num + num1 : num * num1);
        System.out.println(1);

        //  4 С помощью Random сгенерируйте три числа.
        //  Напишите программу, которая находит максимальное из них.
        //  Используйте тернарные операторы.

        Random random = new Random();
        int a = random.nextInt(10);
        System.out.println(a);
        int b = random.nextInt(10);
        System.out.println(b);
        int c = random.nextInt(10);
        System.out.println(c);
        if (a > b && a > c){
            System.out.println(a);
        }else
            if (b > c){
                System.out.println(b);
            }else
                System.out.println(c);
        }
        }














//  2 уровень сложности: