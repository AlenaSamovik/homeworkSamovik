import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Проект 2. Используйте for.
        // Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
        // Пользователь указывает нижнюю и верхнюю границу диапазона.
        Scanner scanner = new Scanner(System.in);
        System.out.println("vvedite niznuu granicu diapozona");
        int a = scanner.nextInt();
        System.out.println("vvedite verhnuu granicu diapozona");
        int b = scanner.nextInt();
        int sum = 0;
        for (int i = a; i <= b; i++) {
            if (i % 2 != 0) {
                sum += i;
                System.out.print(i + " + ");
            }
        }
        System.out.println(" = " + sum);
        System.out.println("ura ura!!!");
    }
}