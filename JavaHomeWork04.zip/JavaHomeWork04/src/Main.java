public class Main {
    public static void main(String[] args) {
        // Projekt 1
        byte b = 1;
        short s = b;
        int i = b;
        long l = b;
        double d = b;
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(d);
        System.out.println();
        //Projekt 2
        long lo = 1000L; 
        byte b1 = (byte) lo;
        short s1 = (short) lo;
        int i1 = (int) lo;
        double d1 = lo;
        System.out.println(b1);
        System.out.println(s1);
        System.out.println(i1);
        System.out.println(d1);
        //Proekt 3
        String str = "I study Basic Java";
        System.out.println(str.charAt(0));
        System.out.println(str.charAt(str.length() -1));
        System.out.println(str.contains("Java"));
        System.out.println(str.replaceAll("a", "o"));
        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());
        System.out.println(str.substring(0, 14));
    }
}