import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //  2 Создайте случайно заполненный числовой массив, выведите его в консоль.
        //  Найдите максимальное по модулю число в массиве и выведите его в консоль.
        int[] numbersArray = {54, 27, 674, -876, -123456789, 123456};
        System.out.println(Arrays.toString(numbersArray));


        int max = numbersArray[0];
        for (int i = 1; i < numbersArray.length; i++) {
            if (Math.abs(numbersArray[i]) > max) {
                max = numbersArray[i];
            }
        }
        System.out.println(max);
    }
}