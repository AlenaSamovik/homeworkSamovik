import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //3 Пользователь вводит строку.
        // Разместите буквы в строке по алфавиту
        // и выведите в консоль.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bвeдитe строку");
        String str = scanner.nextLine();
        String[] strLetters = str.split("");

        //Arrays.sort(strLetters);
        //System.out.println(Arrays.toString(strLetters));
        //v vivode mne ne nraviatsa probeli i zapiatie. idem dalshe
        //System.out.println();
        //massiv strLetters kladu v String chtobi ubrat' probeli i zapiatie.
        String strLettersAsString = Arrays.toString(strLetters);
        String str1 = strLettersAsString.replaceAll("\\s, ", "");
        System.out.println(str1);
        System.out.println();
        //dlia sortirovki kladu String str1 v massiv
        String[] array = new String[]{str1};
        //i sortiruiu
        Arrays.sort(array);
        System.out.println(Arrays.toString(array));
    }
}