import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь вводит строку.
        // Посчитайте количество слов в строке и выведите в консоль.
        // Разделителем между словами считать только пробел.
        // Если в строке есть слова, которые длиннее трёх символов,
        // то вывести эти слова в консоль.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bвeдитe строку");
        String userLine = scanner.nextLine();
        String[] wordsArray = userLine.split(" ");
        System.out.println(Arrays.toString(wordsArray));
        System.out.println("Kolichestvo slov vo fraze " + wordsArray.length);
        for (String s : wordsArray) {
            if (s.length() > 3) {
                System.out.println(s.toCharArray());
            }
        }
    }
}
        /*int count = 0;//kolichestvo slov kladu v Per count = 0;
        //esli est' slovo, +1
        if (userLine.length() != 0) {
            count++;
            //proveraem stroku na nalichie slov
            for (int i = 0; i < userLine.length(); i++) {
                if (userLine.charAt(i) == ' ') { //posle kazdogo probela +1 slovo v chetchike
                    count++;
                }
            }
            System.out.println("Kolichestvo slov vo fraze - " + count);
        */


//Решение состоит из следующих шагов:
//Сохранить фразу пользователя (здесь у Вас всё в порядке).
//Разбить сохранённую строку на массив слов words с помощью split(),
// указав в качестве разделителя пробел.
//Свойство полученного массива words.length - это и есть количество слов
// в строке пользователя. Это значение можно вывести в консоль.
//Для того, чтобы вывести слова, которые длиннее трёх символов,
// нужно организовать цикл по массиву words - это может быть for или foreach.
// Внутри цикла нужно проверить: если длина слова больше 3 символов,
// то вывести слово в консоль.



