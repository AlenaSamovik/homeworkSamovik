import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //1. Двумерные массивы
        //1 Создайте двумерный массив и заполните его буквами русского алфавита.
        char[][] azbuka = new char[6][6];
        char first = 'А';
        char last = 'Я';
        for (int i = 0; i < azbuka.length; i++) {
            for (int j = 0; j < azbuka[i].length; j++) {
                azbuka[i][j] = first;
                first++;
                if (first > last) {
                    break;
                }
            }
        }
        System.out.println(Arrays.deepToString(azbuka));
        System.out.println();

    }
}