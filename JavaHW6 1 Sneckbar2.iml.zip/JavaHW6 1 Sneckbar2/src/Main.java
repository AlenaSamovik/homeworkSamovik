import java.util.Scanner;

public class Main {
    //1 уровень сложности: Проект 1. Перечисления
    //Создайте перечисление для угощений в снек-автомате (3-4 позиции).
    //Пользователь вводит номер снека. Программа должна вывести название снека, который выдал автомат.

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("ukazite nomer sneka");
        int sneckNum = scanner.nextInt() - 1;

            if (sneckNum == 1) {
                System.out.println("vi vibrali " + SNEKS.CHIPS);
            }
            if (sneckNum == 2) {
                System.out.println("vi vibrali " + SNEKS.CHIPS);
            }
            if (sneckNum == 3) {
                System.out.println("vi vibrali " + SNEKS.NOCHWAS);
            }
            if (sneckNum == 4) {
                System.out.println("vi vibrali " + SNEKS.NIAMNIAM);
            }
        }

    }


