public enum SNEKS {
    CHIPS, MARS, NOCHWAS, NIAMNIAM

}
