public class Main {
    public static void main(String[] args) {
        boolean y1 = 2 % 2 ==0;
        boolean y2 = 17 % 2 ==0;
        boolean y3 = 13 % 2 ==0;
        boolean y4 = 14 % 2 ==0;
        System.out.println("true - chetnoe, false - nechetnoe " + y1);
        System.out.println("true - chetnoe, false - nechetnoe " + y2);
        System.out.println("true - chetnoe, false - nechetnoe " + y3);
        System.out.println("true - chetnoe, false - nechetnoe " + y4);

    }
}