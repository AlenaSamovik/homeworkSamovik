import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("vvedite 3h znachnoe chislo.");
        int chislo = scanner.nextInt();
        System.out.println(chislo);
        System.out.println();
        int chislo2 = chislo / 100;
        System.out.println(chislo2);
        System.out.println();
        int chislo3 = chislo / 10 % 10;
        System.out.println(chislo3);
        System.out.println();
        int chislo1 = chislo % 10;
        System.out.println(chislo1);
    }
}