import java.util.Scanner;

public class Main {
    //1 уровень сложности: Проект 1. Перечисления
    //Создайте перечисление для угощений в снек-автомате (3-4 позиции).
    //Пользователь вводит номер снека. Программа должна вывести название снека, который выдал автомат.

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("ukazite nomer sneka");
        int sneckNum = scanner.nextInt() - 1;
        String sneckName = null;
        if (SNECKS.SANDWICH.ordinal() == sneckNum) {
            sneckName = SNECKS.SANDWICH.name();
        }
        if (SNECKS.HOTDOG.ordinal() == sneckNum) {
            sneckName = SNECKS.HOTDOG.name();
        }
        if (SNECKS.CHEESBRGR.ordinal() == sneckNum) {
            sneckName = SNECKS.CHEESBRGR.name();
        }
        if (SNECKS.HAMBRGR.ordinal() == sneckNum) {
            sneckName = SNECKS.HAMBRGR.name();
        }
        System.out.println("vi vibrali " + sneckName);
        System.out.println("gip gip ura!!!");

    }

}