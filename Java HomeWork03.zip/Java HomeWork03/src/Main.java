import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();

        int chislo1 = random.nextInt(999);
        int chislo2 = random.nextInt(999);
        int chislo3 = random.nextInt(999);

        int summa = chislo1 + chislo2 + chislo3;
        System.out.println("summa chisel = " + summa);
        int proizvedenie = chislo1 * chislo2 * chislo3;
        System.out.println("proizvedenie chisel = " + proizvedenie);
    }
}