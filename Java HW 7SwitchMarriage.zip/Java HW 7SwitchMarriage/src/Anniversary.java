public enum Anniversary {
    GAUZE_ANNIVERSARY("Ситцевая (марлевая) свадьба"),
    PAPER_ANNIVERSARY("Бумажная свадьба"),
    LEATHER_ANNIVERSARY("Кожаная свадьба"),
    LINEN_ANNIVERSARY("Льняная свадьба"),
    WOODEN_ANNIVERSARY("Деревянная свадьба"),
    CAST_ANNIVERSARY("Чугунная свадьба"),
    COOPER_ANNIVERSARY("Медная (Шерстяная) свадьба"),
    STANNIC_ANNIVERSARY("Жестяная свадьба"),
    CAMOMILE_ANNIVERSARY("Фаянсовая (ромашковая) свадьба"),
    TIN_ANNIVERSARY("Оловянная свадьба"),
    STEEL_ANNIVERSARY("Стальная свадьба"),
    NICKEL_ANNIVERSARY("Никелевая свадьба"),
    LILY_ANNIVERSARY(" Кружевная (ландышевая) свадьба"),
    AGAT_ANNIVERSARY("Агатовая свадьба"),
    GLASS_ANNIVERSARY("Хрустальная (Стеклянная) свадьба"),
    TOPAZ_ANNIVERSARY("Топазовая свадьба"),
    ROSE_ANNIVERSARY("Розовая свадьба"),
    TURQUOISE_ANNIVERSARY("Бирюзовая свадьба"),
    GARNET_ANNIVERSARY("Гранатовая свадьба"),
    PORCELAIN_ANNIVERSARY(" Фарфоровая свадьба"),
    OPAL_ANNIVERSARY("Опаловая свадьба"),
    BRONZE_ANNIVERSARY(" Бронзовая свадьба"),
    BERYL_ANNIVERSARY("Берилловая свадьба"),
    SATIN_ANNIVERSARY(" Атласная свадьба"),
    SILVER_ANNIVERSARY("Серебряная свадьба");
    private final String translation;
    Anniversary(String translation) {this.translation = translation; }
    public String getTranslation() {return translation; }
}
