import java.util.Scanner;

public class Main {
    //1 уровень сложности: Пользователь вводит, сколько лет он состоит в браке.
    // Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Сколько лет Вы состоите в браке?");
        int years = scanner.nextInt();
        String message = switch (years + 1) {
            case 1 -> concat(Anniversary.GAUZE_ANNIVERSARY);
            case 2 -> concat(Anniversary.PAPER_ANNIVERSARY);
            case 3 -> concat(Anniversary.LEATHER_ANNIVERSARY);
            case 4 -> concat(Anniversary.LINEN_ANNIVERSARY);
            case 5 -> concat(Anniversary.WOODEN_ANNIVERSARY);
            case 6 -> concat(Anniversary.CAST_ANNIVERSARY);
            case 7 -> concat(Anniversary.COOPER_ANNIVERSARY);
            case 8 -> concat(Anniversary.STANNIC_ANNIVERSARY);
            case 9 -> concat(Anniversary.CAMOMILE_ANNIVERSARY);
            case 10 -> concat(Anniversary.TIN_ANNIVERSARY);
            case 11 -> concat(Anniversary.STEEL_ANNIVERSARY);
            case 12 -> concat(Anniversary.NICKEL_ANNIVERSARY);
            case 13 -> concat(Anniversary.LILY_ANNIVERSARY);
            case 14 -> concat(Anniversary.AGAT_ANNIVERSARY);
            case 15 -> concat(Anniversary.GLASS_ANNIVERSARY);
            case 16 -> concat(Anniversary.TOPAZ_ANNIVERSARY);
            case 17 -> concat(Anniversary.ROSE_ANNIVERSARY);
            case 18 -> concat(Anniversary.TURQUOISE_ANNIVERSARY);
            case 19 -> concat(Anniversary.GARNET_ANNIVERSARY);
            case 20 -> concat(Anniversary.PORCELAIN_ANNIVERSARY);
            case 21 -> concat(Anniversary.OPAL_ANNIVERSARY);
            case 22 -> concat(Anniversary.BRONZE_ANNIVERSARY);
            case 23 -> concat(Anniversary.BERYL_ANNIVERSARY);
            case 24 -> concat(Anniversary.SATIN_ANNIVERSARY);
            case 25 -> concat(Anniversary.SILVER_ANNIVERSARY);
            default -> "vveden nevernii nomer";
        };
        System.out.println(message);
    }

    private static String concat(Anniversary anniversary) {
        return "Искренние поздравления. В следующем году у Вас " + anniversary.getTranslation();
    }
}